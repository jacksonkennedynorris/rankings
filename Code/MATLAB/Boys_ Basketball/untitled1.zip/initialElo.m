function initialElo = initialElo(Teams)

initialElo = [];
for i = 1:length(Teams)
    initialElo(i) = 1500;
end
