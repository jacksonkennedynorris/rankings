function calculateRatings(game)

massey = masseyRating(game)
colley = colleyRating(game);